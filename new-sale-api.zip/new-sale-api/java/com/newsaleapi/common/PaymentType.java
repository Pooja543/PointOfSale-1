package com.newsaleapi.common;

public enum PaymentType {
	
	Cash,Card,RTSlip,LoyaltyPoints,OtherPayments,UPI

}
