package com.newsaleapi.common;

public enum SaleNature {

	InStore, VideoCall, ShoppingAtHome, COD, Meesho, Myntra, TwoGud

}
