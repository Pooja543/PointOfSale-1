package com.newsaleapi.common;

public class CommonRequestMappigs {

	public static final String NEW_SALE = "newsale";

	public static final String SALE = "sale";

	public static final String CREATE_BARCODE = "createbarcode";
	
	public static final String GET_BARCODE_DETAILS = "getbarcodedetails";

}
